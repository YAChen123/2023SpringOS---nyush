#include <stdio.h>

#include "sh.h"


int main(){
    return shell();
}

